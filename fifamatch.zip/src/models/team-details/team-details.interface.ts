export interface TeamInfo{
    TeamName:string;
    Formation:number;
}