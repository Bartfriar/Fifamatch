export const firebaseconfig = {
    apiKey: "AIzaSyDbYlMY5KYGU9_YKcGL-_I5O22Gpk0A-Gg",
    authDomain: "fifamatch-1f230.firebaseapp.com",
    databaseURL: "https://fifamatch-1f230.firebaseio.com",
    projectId: "fifamatch-1f230",
    storageBucket: "fifamatch-1f230.appspot.com",
    messagingSenderId: "459025938468"
}
