import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { AngularFireAuth } from '@angular/fire/auth';
import { AngularFireDatabase, snapshotChanges } from '@angular/fire/database';
import * as firebase from 'firebase';
import { GamePage } from '../game/game';
import { MatchPage } from '../match/match';

/**
 * Generated class for the RequestsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-requests',
  templateUrl: 'requests.html',
})
export class RequestsPage {

  users:any;
  oppodet:any;
  currentuser:string;
  currentuserkey:string;
  useremail:string;
  challenger:string;
  constructor(public navCtrl: NavController, 
    public afAuth: AngularFireAuth, 
    public afdb: AngularFireDatabase,
    public navparams:NavParams) {
      afdb.list(`users`).snapshotChanges().subscribe((user: any) => {
        this.users = user;
       if (user.key==afAuth.auth.currentUser.uid){
        console.log(user );
       } 
      
      // this.useremail = this.afAuth.auth.currentUser.email;
      // console.log(this.useremail);

      // firebase.database().ref("users").orderByChild("email").equalTo(this.useremail).on("child_added", usern=>{
      //   this.currentuserkey = usern.key;
      //   this.currentuser = usern.val().username
        
        
      // })
      
      // firebase.database().ref(`users/${this.currentuserkey}/Challenges`).orderByChild("Opponent").equalTo(this.currentuser).on("child_added", chal=>{
      //   this.challenger = chal.val().Opponent
      //   console.log(this.challenger);
      // })
      
      // firebase.database().ref('users').on('value' , userre=>{
      //   userre.forEach((chose:any) =>{
      //       chose.val().team;
      //       this.oppodet = chose.val().Opponent;
      //       console.log(this.oppodet)
      //     });
      // })


    });
  }
  accept(opponent){
    firebase.database().ref(`users/${opponent.key}/Challenges`)
    this.navCtrl.push(MatchPage);
  }
  decline(){

  }

}
