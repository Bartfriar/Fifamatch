import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AmateurPage } from './amateur';

@NgModule({
  declarations: [
    AmateurPage,
  ],
  imports: [
    IonicPageModule.forChild(AmateurPage),
  ],
})
export class AmateurPageModule {}
